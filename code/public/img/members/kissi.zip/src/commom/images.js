const path="http://pbc25z555.bkt.clouddn.com/";
//构建app的图片
export default{
    //logo
    logo:path+"logo.png",
    app_name:path+"app_name.png",
    //导航
    back:path+"back.png",
    back_white:path+"back_white.png",
    share:path+"share.png",
    share_white:path+"share_white.png",
    btn_search:path+"btn_search.png",
    tag_more:path+"tag_more.png",
    btn_quwan:path+"btn_quwan.png",
    //导航

    //分享平台logo
    wechat_logo:path+"wechat_logo.png",
    qzone_logo:path+"qzone_logo.png",
    qq_logo:path+"qq_logo.png",
    friends_logo:path+"friends_logo.png",
    weibo_logo:path+"weibo_logo.png",
    //分享平台logo

    //评分
    comment_like:path+"comment_like.png",
    comment_general:path+"comment_general.png",
    comment_dislike:path+"comment_dislike.png",
    //评分

    //排名
    tag_rank1:path+"tag_rank1.png",
    tag_rank2:path+"tag_rank2.png",
    tag_rank3:path+"tag_rank3.png",
    //排名

    //写评论分享评论气泡
    share_comment:path+"share_comment.png",
    write_comment:path+"write_comment.png",
    //写评论分享评论气泡


    qq_logo_circle:path+"qq_logo_circle.png",
    wechat_logo_circle:path+"wechat_logo_circle.png",
    qq_logo_circle_1:path+"qq_logo_circle_1.png",
    wechat_logo_circle_1:path+"wechat_logo_circle_1.png",

    //浮层关闭按钮
    dialog_close:path+"dialog_close.png",
    dialog_close_1:path+"dialog_close_1.png",
    //浮层关闭按钮

    comment_list_like:path+"comment_list_like.png",
    comment_list_like_white:path+"comment_list_like_white.png",
    
    btn_wanyiwan:path+"btn_wanyiwan.png",
    jrqs_bg_1:path+"jrqs_bg_1.png",
    tag_qq:path+"tag_qq.png",
    tag_weixin:path+"tag_weixin.png",
    dialog_close_for_share:path+"dialog_close_for_share.png",
    qrcode:path+"qrcode.png",
    comment_edit:path+"comment_edit.png",
    comment_jingxuan_bg:path+"comment_jingxuan_bg.png",
    comment_jingxuan_bg1:path+"comment_jingxuan_bg1.png",
    comment_jingxuan_bg2:path+"comment_jingxuan_bg2.png",
    radiobox_checked:path+"radiobox_checked.png",
    radiobox:path+"radiobox.png",
    right_arrow:path+"right_arrow.png",
    comment_list_sort:path+"comment_list_sort.png",
    login:path+"login.png",

    //内容占位图
    avatar:path+"avatar.jpg",
    banner:path+"banner.png",
    banner_1:path+"banner_1.png",
    banner_2:path+"banner_2.png",
    game_bg_3:path+"game_bg_3.png",
    game_bg_2:path+"game_bg_2.png",
    game_bg_1:path+"game_bg_1.png",
    game_min:path+"game_min.png"
}