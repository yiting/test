const path="http://pa1uwtuke.bkt.clouddn.com/";
export default{
    //构建app的图片
    BEBAS:path+"BEBAS.TTF",
}