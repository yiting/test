<template>
    <div class="score">
        <div class="row row-center">
            <text class="no-score">评价人数不足，无法生成分数</text>
        </div>
        <div class="row">
            <div class="totol-score column column-center">
                <text class="totol-score-num">8.9</text>
                <text class="totol-score-peoples-num">3244评价</text>
            </div>
            <div class="ladder-score">
                <div class="row column-center ladder-score-item">
                    <image class="comment-ico" :src="images.comment_like"></image>
                    <!-- 最大宽290px -->
                    <div class="comment-like-progress" style="width:290px"></div>
                    <text class="comment-num">24234234</text>
                </div>
                <div class="row column-center ladder-score-item">
                    <image class="comment-ico" :src="images.comment_general"></image>
                    <!-- 最大宽290px -->
                    <div class="comment-general-progress" style="width:240px"></div>
                    <text class="comment-num">3423334</text>
                </div>
                <div class="row column-center ladder-score-item">
                    <image class="comment-ico" :src="images.comment_dislike"></image>
                    <!-- 最大宽290px -->
                    <div class="comment-dislike-progress" style="width:130px"></div>
                    <text class="comment-num">234234</text>
                </div>
            </div>
        </div>
        <div class="line"></div>
    </div>
</template>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
                images:images
            }
        }
    };
</script>

<style scoped>
    .score{
        padding-top: 40px;
        /*padding-bottom: 40px;*/
        padding-left: 40px;
        padding-right: 40px;
    }
    .no-score{
        padding-top: 10px;
        padding-bottom: 10px;
        color: #bbbbbb;
        font-size: 28px;
    }
    .totol-score-num{
        font-size: 100px;
        color: #000000;
    }
    .totol-score-peoples-num{
        font-size: 28px;
        color: #888888;
    }
    .ladder-score{
        margin-left: 55px;
    }
    .ladder-score-item{
        margin-bottom: 16px;
    }
    .comment-ico{
        width: 36px;
        height: 36px;
    }
    .comment-like-progress,.comment-general-progress,.comment-dislike-progress{
        height: 20px;
        border-radius: 10px;
        overflow: hidden;
        margin-left: 18px;
        margin-right: 18px;
    }
    .comment-like-progress{
        background-color: #1AE0A9
    }
    .comment-general-progress{
        background-color: #FDD479
    }
    .comment-dislike-progress{
        background-color: #FE7573
    }
    .comment-num{
        font-size: 24px;
        color: #BBBBBB;
    }
    .line{
        margin-top: 40px;
        height: 1px;
        background-color: #e1e1e1;
    }

    .row{
        flex-direction: row;
    }
    .row-right{
        justify-content:flex-end;
    }
    .row-center{
        justify-content:center;
    }
    .row-between{
        justify-content:space-between;
    }
    .row-around{
        justify-content:space-around;
    }
    .row-left{
        justify-content:flex-start;
    }
    .column{
        flex-direction: column;
    }
    .column-top{   
        align-items: flex-start;
    }
    .column-center{   
        align-items: center;
    }
    .column-bottom{   
        align-items: flex-end;
    }
</style>


















