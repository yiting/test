<template>
    <div class="game-list">
        <div class="left">
            <div class="thumb-wrap">
                <image class="thumb" :src="images.game_bg_3"></image>
                <!--comment-like
                comment_general
                comment_dislike -->
                <image class="comment-ico" :src="images.comment_like"></image>
            </div>
            <div class="info">
                <div class="row">
                    <text class="name">同学上天吗？</text>
                    <text class="score">9.8</text>
                </div>
                <div class="row">                
                    <text class="comments-num">2.2万人评价</text>
                </div>
                <div class="row">                
<!--                     <text class="style1">未评价</text> 
                    <text class="style1 gap">|</text> -->
                    <text class="style1">最近在qq玩</text>
                </div>
            </div>
        </div>
        <div class="right">
            <image class="btn" :src="images.btn_wanyiwan"></image>
        </div>
        <div class="border"></div>
    </div>
</template>
<style scoped>
.border{
    position: absolute;
    right: 0;
    bottom: 0;
    height: 1px;
    background-color: #e6e6e6;
    width: 586px;
}
.game-list {
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
    padding-left: 40px;
    background-color: #fff;
    padding-bottom: 20px;
    box-sizing: border-box;
}
.row{
    justify-content: flex-start;
    align-items: center;
    flex-direction: row;
}
.left {
    position: relative;
    justify-content: flex-start;
    align-items: center;
    flex-direction: row;
    flex:1;
}

.sort {
    width: 50px;
    justify-content: flex-start;
    align-items: center;
    flex-direction: row;
}

.num {
    font-size: 36px;
    color: #000000;
    font-weight: 900;
}

.thumb-wrap {
    position: relative;
    width: 120px;
    height: 145px;
    padding-top: 10px;
    /*border-radius: 10px;*/
}

.thumb {
    width: 100px;
    height: 125px;
    border-radius: 10px;
}

.name {
    font-size: 32px;
    color: #000;
    padding-right: 10px;
}

.friends-num {
    font-size: 28px;
    color: #888888;
}

.comments-num {
    font-size: 28px;
    color: #888888;
}

.info {
    padding-left: 10px;
    width: 400px;
    lines:1;
}

.right {
    padding-right: 40px;
    justify-content:space-around;
    align-items: center;
    flex-direction: row;

}

.score {
    font-family: BEBAS;
    font-size: 36px;
    color: #ffc557
}
.style1{
    font-size: 28px;
    color: #888888;
    
}
.btn{
    position: relative;
    width: 116px;
    height: 60px;
}
.tag{
    width: 30px;
    height: 30px;
    margin-left: 10px;
}
.gap{
    padding-left: 10px;
    padding-right: 10px;
}
.comment-ico{
    width: 36px;
    height: 36px;
    position: absolute;
    bottom: 2px;
    right: 2px;
}
</style>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
                images:images
            }
        }
    };
</script>
