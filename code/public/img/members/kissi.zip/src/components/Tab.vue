<template>
    <!-- 导航 -->
    <div class="tab">
        <div class="title-item" v-for="(tab,index) in tabs" @click="showTabIndex(index)">
            <text class="text" :class="[index==tabIndex ? 'current' : '']">{{tab.name}}</text>
        </div>
    </div>
</template>
<script>
    import images from '../commom/images';
    export default {
        props: ["tabs","tabIndex"],
        data() {
            return{

            }
        },
        methods:{
          showTabIndex(index) {  
            this.$emit('showTab',index);//select事件触发后，自动触发showCityName事件  
          }  
        }  
    };
</script>
<style scoped>
    .tab {
        background-color: #ffffff;
        justify-content: space-around;
        align-items: flex-end;
        flex-direction: row;
        height: 80px;
        border-bottom-width: 1px;
        border-bottom-color: #E0E0E0;
        border-bottom-style: solid;
    }
    .text{
        position: relative;
        height: 79px;
        line-height: 79px;
        justify-content: center;
        align-items: center;
        color: #000000;
        font-size: 28px;
        border-bottom-width: 8px;
        border-color: rgba(255,255,255,0);
        padding-left: 22px;
        padding-right: 22px;
        margin-left: 72px;
        margin-right: 72px;
        margin-top: 1px;
    }
    .current {
        border-color: #FBD78C;
    }
</style>