<template>
    <div class="slider-wrap">
        <slider class="slider" interval="3000" auto-play="true">
            <div class="frame" v-for="img in imageList">
                <image class="image" resize="cover" :src="img.src"></image>
                <div class="info">
                    <div class="info-left">
                        <div class="row row1">
                            <text class="name">深海水族馆</text>
                            <text class="score">9.8</text>
                        </div>
                        <div class="row row2">
                            <image class="avatar" :src="img.avatar"></image>
                            <image class="avatar" :src="img.avatar"></image>
                            <image class="avatar" :src="img.avatar"></image>
                            <text class="text-1">1866人推荐</text>
                        </div>
                    </div>
                    <div class="info-right">
                        <image class="btn" :src="images.btn_quwan"></image>
                    </div>
                </div>
            </div>
        </slider>
    </div>
</template>
<style scoped>
.slider-wrap{
    border-radius: 10px;
    padding-left: 40px;
    /*margin-top: -10px;*/
}
.slider {
    width: 670px;
    height: 511px;
}
.frame {
    width: 670px;
    height: 511px;
    position: relative;
}
.image {
    width: 670px;
    height: 377px;
    border-radius: 10px;
    overflow: hidden;
}
.info{
    height: 134px;
    flex-direction:row;
    justify-content: space-between;
    align-items: center;
}
.avatar{
    width: 30px;
    height: 30px;
    margin-right: 6px;
    border-radius: 15px;
}
.name{
    margin-right: 10px;
    font-size: 32px;
}
.text-1{
    color: #888888;
    font-size: 24px;
}
.row{
    padding-top: 0px;
    padding-bottom: 0px;
    flex-direction:row;
    justify-content: flex-start;
    align-items: center;
}
.row2{
    margin-top: 2px;
}
.score{
    font-family: BEBAS;
    color: #ffc557;
}
.btn{
    width: 120px;
    height: 56px;
}

</style>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
                images:images,
                imageList: [{
                        src: images.banner,
                        avatar:images.avatar
                    },
                    {
                        src: images.banner,
                        avatar:images.avatar
                    },
                    {
                        src: images.banner,
                        avatar:images.avatar
                    }
                ]
            }
        }
    };
</script>