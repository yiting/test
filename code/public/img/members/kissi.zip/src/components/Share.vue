<template>
    <div class="share">
        <div class="mask"></div>
        <!-- 分享评论 -->
        <div class="share-dialog share-comment align-up" v-if="true">
            <div class="share-dialog-inner">
                <div class="share-dialog-head">
                    <image :src="images.banner" class="banner-image"></image>
                    <div class="game-info">
                        <text class="game-name">跳一跳 </text>
                        <text  class="game-score">8.7分</text>
                    </div>
                </div>
                <div class="share-dialog-body">
                    <div class="user-info">
                        <image class="user-avatar red-border" :src="images.avatar"></image>
                        <div class="user-content">
                            <div class="row column-center">
                                <text class="user-name">为游戏而生</text>
                            </div>
                            <div>
                                <text class="tuijian">推荐玩</text>
                            </div>
                        </div>
                    </div>
                    <text class="share-text">国产游戏中的佼佼者，拥有丰富的解谜元素、大量的菜单和梗。拥有丰富的解谜元素、大量的菜单哈哈哈哈…
                    </text>
                    <div class="line"></div>
                    <div class="ways share-comment-ways">
                        <div class="share-comment-ways-part1">
                            <image :src="images.qrcode" class="qrcode share-comment-qrcode"></image>
                        </div>
                        <div class="share-comment-ways-part2">
                            <text class="comment-tips">长按识别二维码</text>
                            <text class="comment-tips">体验更多好玩的小游戏</text>
                        </div>
                    </div>
                </div>
            </div> 
            <image  class="share-dialog-close" :src="images.dialog_close_for_share"></image>
        </div>
        <!-- 分享游戏 -->
        <div class="share-dialog share-game align-up" v-if="false">
            <div class="share-dialog-inner">
                <div class="share-dialog-head">
                    <image :src="images.banner" class="banner-image"></image>
                    <div class="game-info">
                        <text class="game-name">跳一跳 </text>
                        <text  class="game-score">8.7分</text>
                    </div>
                </div>
                <div class="share-dialog-body">
                    <text class="share-text">国产游戏中的佼佼者，拥有丰富的解谜元素、大量的菜单和梗。拥有丰富的解谜元素、大量的菜单哈哈哈哈…
                    </text>
                    <div class="ways share-game">
                        <div class="share-game-ways-part1">
                            <image :src="images.qrcode" class="qrcode share-game-qrcode"></image>
                        </div>
                        <div class="share-game-ways-part2">
                            <text class="comment-tips black">长按识别二维码,体验更多好玩的小游戏</text>
                            <text class="comment-tips">在微信或QQ中搜索“跳一跳”即可畅玩</text>
                        </div>
                    </div>
                </div>
            </div>
            <image  class="share-dialog-close" :src="images.dialog_close_for_share"></image>
        </div>
        <!-- platom -->
        <div class="shared-platform">
            <div class="shared-platform-head">
                <text class="shared-platform-title">分享到</text>
            </div>
            <div class="shared-platform-body">
                <div class="platform-group">
                    <div class="platform-item">
                        <div class="platform-logo-wrap">
                            <image class="platform-logo" :src="images.qq_logo"></image>
                        </div>
                        <text class="platform-name">QQ</text>
                    </div>
                    <div class="platform-item">
                        <div class="platform-logo-wrap">
                            <image class="platform-logo" :src="images.qzone_logo"></image>
                        </div>
                        <text class="platform-name">QQ空间</text>
                    </div>
                    <div class="platform-item">
                        <div class="platform-logo-wrap">
                            <image class="platform-logo" :src="images.wechat_logo"></image>
                        </div>
                        <text class="platform-name">微信</text>
                    </div>
                    <div class="platform-item">
                        <div class="platform-logo-wrap">
                            <image class="platform-logo" :src="images.friends_logo"></image>
                        </div>
                        <text class="platform-name">朋友圈</text>
                    </div>
                    <div class="platform-item">
                        <div class="platform-logo-wrap">
                            <image class="platform-logo" :src="images.weibo_logo"></image>
                        </div>
                        <text class="platform-name">微博</text>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<style scoped="">
    /*分享*/
    .share{
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        flex-direction: column;
        align-items:center;
        justify-content: center;
    }
    /*mask*/
    .mask{
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0,0,0,.75);
    }
    .share-dialog{
        width: 700px;
        padding-top: 50px;
        flex-direction: column;
        align-items:center;
        justify-content: center;
    }
    .share-dialog-inner{
        width: 580px;
        position: relative;
        border-radius: 10px;
        background-color: #ffffff;  
    }
    .align-up{
        margin-bottom: 200px;
    }
    .share-dialog-close{
        position: absolute;
        left:0px;
        top:0px;
        width: 40px;
        height: 40px;
    }
    .share-dialog-head{
        width:580px;
        height: 500px;
    }
    .game-info{
        position: absolute;
        top: 434px;
        left: 30px;
        flex-direction: row;
        align-items:center;
        justify-content: flex-start;
    }
    .game-name{
        color: #ffffff;
        font-size: 36px;
    }
    .game-score{
        color: #ffffff;
        font-size: 36px;
    }
    .banner-image{
        width:580px;
        height: 500px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }
    .ways{
        padding-left: 30px;
        padding-right: 30px;
        padding-bottom: 30px;
        padding-top: 30px;
    }
    .share-text{
        lines:4;
        margin-left: 30px;
        margin-right: 30px;
        margin-top: 30px;
        font-size: 28px;
        text-overflow: ellipsis;
    }
    .line{
        height: 1px;
        background-color: #E6E6E6;
        margin-left: 30px;
        margin-right: 30px;
    }
    .comment-tips{
        color: #888888;
        font-size: 24px;
    }
    .qrcode{
        width: 70px;
        height: 70px;
    }




    /*分享评论*/
    .share-comment{
    }
    .share-comment-ways{
        flex-direction: row;
        align-items:center;
        justify-content: flex-start;
    }
    .share-comment-qrcode{
        width: 70px;
        height: 70px;
    }

    .share-comment-ways-part1{
        margin-right: 20px;
    }
    .share-comment-ways-part2{
        flex-direction: column;
        align-items:flex-start;
        justify-content: flex-start;
    }

    /*分享游戏*/
    .share-game{
        flex-direction: column;
        align-items:center;
        justify-content: center;
    }
    .share-game-qrcode{
        width: 100px;
        height: 100px;
    }
    .share-game-ways-part1{

    }
    .share-game-ways-part2{
        margin-top: 20px;
        flex-direction: column;
        align-items:center;
        justify-content: center;

    }
    .black{
        color: #000000;
    }




    /*platom*/
    .shared-platform{
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 260px;
        background-color: #F2F2F1;
        flex-direction: column;
        align-items:center;
        justify-content: center;
    }
    .shared-platform-head{
        flex-direction: row;
        align-items:center;
        justify-content: center;
        margin-bottom: 20px;
    }
    .shared-platform-body{
        width: 750px;
    }
    .shared-platform-title{
        color: #777777;
        font-size: 20px;
    }
    .platform-group{
        flex-direction: row;
        align-items:center;
        justify-content: space-around;
    }
    .platform-item{
        width: 120px;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }
    .platform-logo-wrap{
        width: 120px;
        height: 120px;
        border-radius: 20px;
        background-color: #ffffff;
        flex-direction: column;
        align-items: center;
        justify-content: center;

    }
    .platform-item:active{
        opacity: .7
    }
    .platform-logo{
        width: 120px;
        height: 120px;
    }
    .platform-name{
        font-size: 20px;
        color: #777777;
        margin-top: 15px;
    }

    .user-info{
        justify-content:flex-start;
        flex-direction: row;
        align-items: center;
        padding-top: 30px;
        padding-left: 30px;
    }
    .user-avatar{
        width: 80px;
        height: 80px;
        border-radius: 30px;
        margin-right: 20px;
    }
    .comment_scoring{
        width: 36px;
        height: 36px;
        position: absolute;
        left: 12px;
        top: 50px;

    }
    .red-border{
        border-color: #FF7373;
    }
    .orange-border{
        border-color: #FFE086;
    }
    .green-border{
        border-color: #1AE0A9;
    }
    .user-name{
        color: #000000;
        margin-right: 12px;
        font-size: 28px;
    }
    .tuijian{
        font-size: 24px;
        color: #bbbbbb;
    }

</style>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
                images:images
            }
        },
        components: { 
            
        }
    };
</script>





