<template>
    <div class="game-list">
        <div class="banner-wrap">
            <image class="banner" :src="images.banner_2"></image>
            <div class="column">
                <text class="game-name">飞机大作战</text>
                <text class="comments-num">26789人已测评</text>
            </div>
            <div class="game-type row">
                <text class="type-text type">竞技</text>
                <text class="type-text line">|</text>
                <text class="type-text sub-type">MOBA</text>
            </div>
        </div>
        <div class="user-wrap">
            <user></user>
        </div>
        <div class="comment">
            <text class="comment-content">团队耗费1年时间打磨的精品游戏。在游戏中华丽定制你的喵咪车手，喜欢就给我们点赞吧~
            </text>
        </div>
        <div class="btn">
            <text class="btn-text">去测评</text>
        </div>
    </div>
</template>
<style scoped>
.game-list {
    width:670px;
    height: 864px;
    margin-bottom: 24px;
    background-color: #fff; 
    border-radius: 10px;
    box-shadow: 0 0 3px rgba(0, 0, 0, 0.20);
    margin-right: 20px;
}
.row{
    justify-content: flex-start;
    align-items: center;
    flex-direction: row;
}
.column{
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
.banner-wrap{
    border-radius: 10px;
    width:670px;
    height: 536px;
    overflow: hidden;
    justify-content: center;
    align-items: center;
    flex-direction: row;
}
.game-name{
    color: #ffffff;
    font-size: 50px;
}
.comments-num{
    color: #ffffff;
    font-size: 28px;
}
.banner {
    position: absolute;
    top: 0;
    left: 0;
    width:670px;
    height: 536px;
}
.game-type{
    position: absolute;
    right: 30px;
    top: 30px;
    height: 48px;
    opacity: .22px;
    padding-left: 13px;
    padding-right: 13px;
    justify-content: center;
    align-items: center;
    flex-direction: row;
    background-color: rgba(255,255,255,.2);
    border-radius: 6px;
}
.line{
    padding-left: 4px;
    padding-right: 4px;
}
.type-text{
    font-size: 24px;
    color: #ffffff;
}
.xiediansha{
    width: 164px;
    height: 61px;
    margin-left: 16px;
}
.comment{
    padding-top: 30px;
    padding-right: 30px;
    padding-bottom: 30px;
    padding-left: 30px;
}
.comment-content{
    font-size: 28px;
    lines:2;
    text-overflow: ellipsis;
}
.btn{
    position: absolute;
    bottom: 0;
    left: 0;
    width: 670px;
    height: 90px;
    border-top-width: 1px;
    border-top-style: solid;
    border-top-color: #E1E1E1;
    justify-content: center;
    align-items: center;
    flex-direction: row;
}
.btn:active{
    opacity: .7
}
.btn-text{
    font-size: 28px;
}
</style>
<script>
import images from '../commom/images'
import user from './user.vue'
export default {
    data() {
        return {
            images:images
        }
    },
    components: {
       user
    },
    mounted() {
        // console.log(this._data.tabs)
        // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
    }
};
</script>













