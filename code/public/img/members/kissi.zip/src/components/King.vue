<template>
    <div class="king">
        <!-- jrqs-bg-1,jrqs-bg-2 背景 -->
        <image class="bg" :src="images.jrqs_bg_1"></image>
        <div class="king-group" ref="listScrollWrap">
            <div class="king-item" v-for="(king,index) in kingList">
                <div class="left">
                    <image class="avatar" :src="images.avatar"></image>
                    <div>
                        <text class="name">{{king.name}}庞建国</text>
                        <text class="contribution">一天内连续评价10款游戏</text>
                    </div>
                </div>
                <div class="right">
                    <text class="get-title">#输出机器#</text>
                </div>
            </div>
        </div>
    </div>
</template>
<style scoped>
    /*骑士部分*/
    .king{
        width: 670px;
        height: 148px;
        border-radius: 10px;
        margin-bottom: 20px;
        margin-left: 40px;
        overflow: hidden;
    }
    .king-group{
        width: 670px;
        flex-direction: column;
        align-items:flex-start;
        justify-content: flex-start;
    }
    .king-item{
        width: 670px;
        height: 148px;
        justify-content: space-between;
        align-items: center;
        flex-direction: row;
        border-radius: 10px;
    }
    .bg{
        position: absolute;
        left: 0;
        top: 0;
        width: 670px;
        height: 148px;
    }
    .left{
        justify-content: flex-start;
        align-items: center;
        flex-direction: row;
        padding-left: 20px;
    }
    .right{
        padding-right: 20px;
    }
    .name{
        font-size: 32px;
        color: #ffffff;
    }
    .contribution{
        font-size: 24px;
        color: #ffffff;
    }
    .get-title{
        color: #ffee71;
        font-size: 32px;
    }
    .avatar{
        width: 108px;
        height: 108px;
        margin-right: 15px;
        border-width: 4px;
        border-color: rgba(255,255,255,.3);
        border-style: solid;
        border-radius: 106px;
    }
</style>
<script>
    import images from '../commom/images';
    const animation = weex.requireModule('animation');
    const modal = weex.requireModule('modal')
    export default {
        data() {
            return {
                images:images,
                timmer:null,//定时器
                kingList:[
                    {
                        name:1,
                    },
                    {

                        name:2,
                    }
                ]
            }
        },
        created:function(){
            //轮播
            var that=this;
            that.kingList=that.kingList.concat(that.kingList[0])
            setTimeout(function(){
                that.showList(that.kingList); 
            },2000)
            //轮播
        },
        methods:{
            showList(listGroup){
                var that=this;
                var oneStepLength=148;
                var total=listGroup.length;
                var index=0;
                var duration=2000;
                that.timmer && clearInterval(that.timmer);
                function move(index,duration,callback){
                    animation.transition(that.$refs.listScrollWrap, {
                        styles: {
                            transform: `translateY(${-oneStepLength * index}px)`,
                        },
                        duration: duration, 
                        timingFunction: 'ease',
                        delay: 0 
                    }, () => {
                        callback && callback()
                    });
                };
                that.timmer=setInterval(function(){
                    move(index++,400,function(){
                        if(index==(total)){
                            index=0;
                            move(0,0)
                        }
                    });
                },duration)
            } 
        }

    }
</script>