<template>
    <div class="scoring">
        <div class="scoring-head">
            <div class="scoring-head-line"></div>
            <text class="scoring-head-text">这款游戏怎么样?</text>
            <div class="scoring-head-line"></div>
        </div>
        <div class="scoring-body">
            <div class="scoring-item">
                <image class="comment-ico" :src="images.comment_like"></image>
                <text class="scoring-text">不好玩</text>
            </div>
            <div class="scoring-item">
                <image class="comment-ico" :src="images.comment_general"></image>
                <text class="scoring-text">一般般</text>
            </div>
            <div class="scoring-item">
                <image class="comment-ico" :src="images.comment_dislike"></image>
                <text class="scoring-text">推荐</text>
            </div>
        </div>
        <div class="selected-comment">
            <image class="comment-jingxuan-bg" :src="images.comment_jingxuan_bg"></image>
        </div>
    </div>
</template>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
               "images":images 
            }
        },
        components: { 
        },
        mounted(){
            // console.log(this._data.tabs)
            // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
        }
    };
</script>
<style scoped>
    .scoring{
        background-color: #ffffff;
    }
    .scoring-head{
        justify-content: center;
        flex-direction: row;
        align-items: center;
    }
    .scoring-head-text{
        font-size: 24px;
        color: #bbbbbb;
        padding-left: 10px;
        padding-right: 10px;
    }
    .scoring-head-line{
        height: 2px;
        width: 30px;
        background-color: #d8d8d8;
    }
    .scoring-body{
        padding-top: 20px;
        justify-content: center;
        flex-direction: row;
        align-items: center;
    }
    .comment-ico{
        width: 80px;
        height: 80px;
    }
    .scoring-item{
        padding-left: 35px;
        padding-right: 35px;
        align-items: center;
    }
    .scoring-text{
        font-size: 28px;
        padding-top: 20px;
    }
</style>