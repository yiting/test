<template>
    <div class="game-list">
        <div class="border-bottom"></div>
        <div class="game-content-wrap">
            <div class="left">
                <div class="thumb-wrap">
                    <image class="thumb" :src="images.game_bg_3"></image>
                    <!--commentLike
                    commentGeneral
                    commentDislike -->
                    <!-- <image class="comment-ico" :src="images.commentLike"></image> -->
                </div>
                <div class="info">
                    <div class="row">
                        <text class="name">同学上天吗？</text>
                        <!-- <text class="score">9.8</text> -->
                    </div>
                    <div class="row">                
                        <text class="comments-num">2.2万人评价</text>
                    </div>
                    <div class="row">                
    <!--                     <text class="style1">未评价</text> 
                        <text class="style1 gap">|</text> -->
                        <text class="style1">刚刚玩过</text>
                    </div>
                </div>
            </div>
            <div class="right">
                <image class="btn" :src="images.comment_dislike"></image>
                <image class="shareComment" :src="images.share_comment"></image>
                <image class="writeComment" :src="images.write_comment"></image>
            </div>
        </div>
        <div class="comment-content-wrap">
            <text class="comment-content">新手引导太长，而且还经常闪退是怎么回事？开发者好好优化游戏体验吧！
            </text>
        </div>
    </div>
</template>
<style scoped>
.game-list {
    padding-bottom: 20px;
    padding-top: 20px;
    padding-left: 40px;
    background-color: #fff;
}
.game-content-wrap{
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
}
.border-bottom{
    position: absolute;
    bottom: 0;
    left: 40px;
    height: 1px;
    background-color: #e6e6e6;
    width: 670px;
}
.row{
    justify-content: flex-start;
    align-items: center;
    flex-direction: row;
}
.left {
    position: relative;
    justify-content: flex-start;
    align-items: center;
    flex-direction: row;
    flex:1;
}

.sort {
    width: 50px;
    justify-content: flex-start;
    align-items: center;
    flex-direction: row;
}

.comment-content-wrap{
    width: 670px;
    padding-top: 20px;
    padding-right: 20px;
    padding-bottom: 20px;
    padding-left: 20px;
    background-color: #F4F4F4;
    background-color: #F4F4F4;
    border-radius: 6px;
    margin-top: 20px;
}
.comment-content{
    font-size: 24px;
    color: #888888;
}
.num {
    font-size: 36px;
    color: #000000;
    font-weight: 900;
}

.thumb-wrap {
    position: relative;
    width: 100px;
    height: 125px;
    border-radius: 10px;
}

.thumb {
    width: 100px;
    height: 125px;
    border-radius: 6px;
}

.name {
    font-size: 32px;
    color: #000
}

.friends-num {
    font-size: 28px;
    color: #888888;
}

.comments-num {
    font-size: 28px;
    color: #888888;
}

.info {
    padding-left: 30px;
    width: 400px;
    lines:1;
}

.right {
    padding-right: 40px;
    justify-content:space-around;
    align-items: center;
    flex-direction: row;

}

.score {
    font-family: BEBAS;
    font-size: 36px;
    color: #ffc557
}
.style1{
    font-size: 28px;
    color: #888888;
    
}
.btn{
    position: relative;
    width: 60px;
    height: 60px;
    margin-left: 30px;
}
.tag{
    width: 30px;
    height: 30px;
    margin-left: 10px;
}
.gap{
    padding-left: 10px;
    padding-right: 10px;
}
.comment-ico{
    width: 36px;
    height: 36px;
    position: absolute;
    bottom: -18px;
    right: -18px;
}
.shareComment{
    width: 164px;
    height: 61px;
    margin-left: 16px;
}
.writeComment{
    width: 164px;
    height: 61px;
    margin-left: 16px;
}
</style>
<script>
import images from '../commom/images'
export default {
    data() {
        return {
            images:images
        }
    },
    components: {
    },
    mounted() {
        // console.log(this._data.tabs)
        // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
    }
};
</script>














