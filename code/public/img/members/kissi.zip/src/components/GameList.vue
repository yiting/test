<template>
    <div class="game-list">
        <div class="left">
            <div class="sort" v-if="showRank">
                <text>{{showRank}}</text>
            </div>
            <div class="thumb-wrap">
                <image class="thumb" :src="images.game_bg_3"></image>
            </div>
            <div class="info">
                <div class="row">
                    <text class="name">同学上天吗？</text>
                    <text class="score">9.8</text>
                </div>
                <div class="row">                
                    <text class="comments-num">1000人评价</text>
                    <image class="tag" :src="images.qq_logo_circle"></image>
                    <image class="tag" :src="images.wechat_logo_circle"></image>
                </div>
            </div>
        </div>
        <div class="right">
            <image class="btn" :src="images.btnwanyiwan"></image>
        </div>
    </div>
</template>
<style scoped>
    .game-list {
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        padding-left: 24px;
        background-color: #fff;
    }
    .row{
        justify-content: flex-start;
        align-items: center;
        flex-direction: row;
    }
    .left {
        position: relative;
        justify-content: flex-start;
        align-items: center;
        flex-direction: row;
        flex:1;
    }

    .sort {
        width: 50px;
        justify-content: flex-start;
        align-items: center;
        flex-direction: row;
        margin-right: 16px;
    }

    .num {
        font-size: 36px;
        color: #000000;
        font-weight: 900;
    }

    .thumb-wrap {
        position: relative;
        width: 100px;
        height: 125px;
        border-radius: 10px;
    }

    .thumb {
        width: 100px;
        height: 125px;
    }

    .name {
        font-size: 32px;
        color: #000
    }

    .friends-num {
        font-size: 28px;
        color: #888888;
    }

    .comments-num {
        font-size: 28px;
        color: #888888;
    }

    .info {
        padding-left: 30px;
        width: 400px;
        lines:1;
    }

    .right {
        padding-right: 40px;
        justify-content:space-around;
        align-items: center;
        flex-direction: row;

    }

    .score {
        font-family: BEBAS;
        font-size: 36px;
        color: #ffc557
    }
    .btn{
        position: relative;
        width: 116px;
        height: 60px;
    }
    .tag{
        width: 30px;
        height: 30px;
        margin-left: 10px;
    }
</style>
<script>
    import images from '../commom/images';
    export default{
        props:["showRank"],
        data(){
            return{
                images:images

            }
        }
    };
</script>





