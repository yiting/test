<template>
    <!-- 导航 -->
    <div :style="navStyle"  :class="[
        'navigator',border ? 'border' : '',
        transparentBg ? 'transparentBg' : '',
        ipx ? 'ipx' : ''
    ]">
        <div class="nav-left">
            <!-- back -->
            <image class="back" v-if="back" :src="images.back">
            </image>
            <!--白色的white -->
            <image class="back-white" v-if="back_white" :src="images.back_white"></image>
            <!-- 头像 -->
            <image class="avatar" v-if="avatar" :src="avatar"></image>
        </div>
        <!-- 标题 -->
        <div class="nav-center">
            <text class="title">{{navTitle}}</text>
        </div>
        <!-- 搜索 -->
        <div class="nav-right">
            <image class="search" v-if="search" :src="images.search"></image>
            <image class="share" v-if="share" :src="images.share"></image>
            <image class="share" v-if="share_white" :src="images.share_white"></image>
        </div>
    </div>
</template>
<script>
    import images from '../commom/images';
    export default{
        props:["navTitle","search","avatar","back","back_white","share","share_white","border","transparentBg","navStyle","navTitleStyle"],
        data(){
            return{
                "images":images,
                "ipx":false
            }
        }
    };
</script>
<style scoped>
    /*导航*/
    .navigator{
        justify-content: space-between;
        align-items: center;
        height: 128px;
        flex-direction: row;
        padding-top: 46px;
        background-color: #ffffff;
    }
    .ipx{
        /*padding-top: 46px;*/
        padding-top: 86px;
        height: 168px;
    }
    .transparentBg{
        background-color: transparent;
    }
    .border{
        border-bottom-width: 2px;
        border-bottom-color: #e1e1e1;
        border-bottom-style: solid;
    }
    .nav-white{
        background-color: #ffffff;
    }
    /*导航左边*/
    .nav-left {
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        padding-left: 40px;
        width: 200px;
    }
    /*导航中间*/
    .nav-center {
        padding-left: 20px;
        padding-right: 20px;
    }
    /*导航右边*/
    .nav-right {
        padding-right: 40px;
        width: 200px;
        flex-direction: row;
        justify-content: flex-end;
        align-items: center;
    }
    .back{
        width: 95px;
        height: 40px;
    }
    .back-white{
        width: 102px;
        height: 43px;
    }
    /*头像*/
    .avatar{
        width: 56px;
        height: 56px;
        border-radius:56px;
        overflow:hidden; 
    }
    /*标题*/
    .title{
        justify-content: center;
        font-size: 40px;
        color: #000000;
    }
    /*搜索*/
    .search{
        width: 36px;
        height: 36px;
    }
    .search:active{
        opacity: .3;
    }
    /*分享*/
    .share{
        width: 55px;
        height: 44px;
        opacity: 1;
    }
    .share:active{
        opacity: .3;
    }
</style>
