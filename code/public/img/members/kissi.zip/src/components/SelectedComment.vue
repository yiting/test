<template>
    <!-- 精选评论 -->
    <!-- selected-comment-like -->
    <!-- selected-comment-dislike -->
    <!-- selected-comment-general -->
    <div class="selected-comment selected-comment-general">
        <image class="comment-jingxuan-bg" :src="images.comment_jingxuan_bg"></image>
        <div class="edit-result-wrap">
            <!-- 用户信息 -->
            <div class="user-info">
                <image class="user-avatar" :src="images.avatar"></image>
                <div class="user-content">
                    <div class="row column-center">
                        <text class="user-name">为游戏而生</text>
                        <text class="user-tag">殿堂骑士</text>
                    </div>
                    <div>
                        <text class="user-online-time">20分钟前</text>
                    </div>
                </div>
            </div>
            <!-- 评论内容 -->
            <text class="comment-content">非常棒的一款游戏，互动性很强，很适合和小朋友一起玩，能帮助小朋友锻炼思维。</text>
            <!-- 撰写评论 -->
            <div class="row row-right">
                <div class="write-comment">
                    <image class="comment-edit" :src="images.comment_edit"></image>
                    <text class="write-comment-text">撰写评论</text>
                </div>
                <div class="share-comment">
                    <image class="share-ico" :src="images.share_ico"></image>
                    <text class="share-comment-text">分享评论</text>
                </div>

            </div>
        </div>
        <div class="share-result-wrap">
            <text class="share-result">“推荐玩”</text>
        </div>
    </div>
</template>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
               "images":images 
            }
        },
        components: { 
        },
        mounted(){
            // console.log(this._data.tabs)
            // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
        }
    };
</script>
<style scoped>
    /*精选评论*/
    .selected-comment{
        border-radius: 20px;
        background-color: #aaaaaa;
        padding-left: 30px;
        padding-top: 30px;
        padding-right: 30px;
        padding-bottom: 30px;
    }
    .selected-comment-like{
        background-color: #1AE0A9;

    }
    .selected-comment-dislike{

        background-color: #FE7573;
    }
    .selected-comment-general{

        background-color: #FDD479;
    }

    .user-info{
        justify-content:flex-start;
        flex-direction: row;
        align-items: center;
    }
    .user-avatar{
        width: 64px;
        height: 64px;
        border-width: 2px; 
        border-color: #ffffff;
        border-style: solid;
        border-radius: 30px;
        margin-right: 20px;
    }
    .user-name{
        color: #Ffffff;
        margin-right: 12px;
        font-size: 28px;
    }
    .user-tag{
        font-size: 22px;
        color: #ffffff;
        border-radius: 22px;
        height: 36px;
        line-height: 36px;
        border-width: 1px;
        border-color: #ffffff;
        border-style: solid;
        padding-left: 12px;
        padding-right: 12px;
    }
    .user-online-time{
        font-size: 24px;
        color: rgba(255,255,255,.7);
    }

    .comment-jingxuan-bg{
        position: absolute;
        right: -30px;
        top: -40px;
        width: 157px;
        height: 157px;
    }


    .write-comment,.share-comment{
        justify-content:flex-end;
        flex-direction: row;
        align-items: center;
    }
    .write-comment:active,.share-comment:active{
        opacity: .7
    }
    .comment-edit,.share-ico{
        width: 27px;
        height: 27px;
    }
    .comment-content{
        font-size: 28px;
        color: #fff;
        padding-bottom: 14px;
        padding-top: 14px;
    }
    .write-comment-text,.share-comment-text{
        color: #ffffff;
        font-size: 28px;
        margin-left: 10px;
    }

    .share-result-wrap{
        padding-top: 42px;
        padding-bottom: 42px;
        justify-content:center;
        flex-direction: row;
        align-items: center;
    }
    .share-result{
        color: #ffffff;
        font-size: 42px;
    }
    .row{
        flex-direction: row;
    }
    .row-right{
        justify-content:flex-end;
    }
    .row-center{
        justify-content:center;
    }
    .row-between{
        justify-content:space-between;
    }
    .row-around{
        justify-content:space-around;
    }
    .row-left{
        justify-content:flex-start;
    }
    .column{
        flex-direction: column;
    }
    .column-top{   
        align-items: flex-start;
    }
    .column-center{   
        align-items: center;
    }
    .column-bottom{   
        align-items: flex-end;
    }

</style>