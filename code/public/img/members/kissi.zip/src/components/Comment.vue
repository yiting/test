<template>
    <!-- 评论 -->
    <div class="comment">
        <image class="comment-jingxuan-bg" :src="images.comment_jingxuan_bg"></image>
        <!-- 用户信息 -->
        <div class="user-info">
            <!-- red-border -->
            <!-- orange-border -->
            <!-- green-border -->
            <image class="user-avatar red-border" :src="images.avatar"></image>
            <image class="comment_scoring" :src="images.comment_dislike"></image>
            <div class="user-content">
                <div class="row column-center">
                    <text class="user-name">为游戏而生</text>
                    <text class="user-tag">殿堂骑士</text>
                </div>
                <div>
                    <text class="user-online-time">20分钟前</text>
                </div>
            </div>
        </div>
        <!--like -->
        <div class="like">
            <!-- comment_list_like_active.png  comment-list-like-num-active 变色-->
            <image class="comment-list-like" :src="images.comment_list_like_white"></image>
            <text class="comment-list-like-num">1000</text>
        </div>
        <!-- 评论内容 -->
        <text class="comment-content">非常棒的一款游戏，互动性很强，很适合和小朋友一起玩，能帮助小朋友锻炼思维。</text>
        <div class="line"></div>
    </div>
</template>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
                images:images,
            }
        }
    };
</script>
<style scoped>
    /*评论*/
    .comment{
        padding-top: 20px;
        padding-left: 40px;
    }
    .like{
        position: absolute;
        top: 41px;
        right: 30px;
        justify-content:flex-end;
        flex-direction: row;
        align-items: center;

    }
    .comment-list-like{
        width: 22px;
        height: 22px;
    }
    .comment-list-like-num{
        margin-left: 5px;
        color: #888888;
        font-size: 24px;
    }

    .comment-list-like-num-active{
        color: #000000;
    }
    .user-info{
        justify-content:flex-start;
        flex-direction: row;
        align-items: center;
        /*margin-bottom: 8px;*/
        height: 90px;
    }
    .user-content{
        margin-top: 8px;
    }
    .user-avatar{
        width: 60px;
        height: 60px;
        border-width: 2px; 
        border-style: solid;
        border-radius: 30px;
        margin-right: 20px;
    }
    .comment_scoring{
        width: 36px;
        height: 36px;
        position: absolute;
        left: 12px;
        top: 50px;

    }
    .red-border{
        border-color: #FF7373;
    }
    .orange-border{
        border-color: #FFE086;
    }
    .green-border{
        border-color: #1AE0A9;
    }
    .user-name{
        color: #000000;
        margin-right: 12px;
        font-size: 28px;
    }
    .user-tag{
        font-size: 22px;
        color: #BACCCF;
        border-radius: 22px;
        border-width: 1px;
        border-color: #BACCCF;
        border-style: solid;
        height: 36px;
        line-height: 36px;
        padding-left: 12px;
        padding-right: 12px;
    }
    .user-online-time{
        font-size: 24px;
        color: #bbbbbb;
    }

    .comment-jingxuan-bg{
        position: absolute;
        right: -30px;
        top: -40px;
        width: 157px;
        height: 157px;
    }
    .comment-content{
        color: #000000;
        font-size: 28px;
        margin-left: 80px;
    }
    .line{
        background-color: #e6e6e6;
        height: 1px;
        margin-top: 24px;
        margin-left: 80px;
    }
    .row{
        flex-direction: row;
    }
    .row-right{
        justify-content:flex-end;
    }
    .row-center{
        justify-content:center;
    }
    .row-between{
        justify-content:space-between;
    }
    .row-around{
        justify-content:space-around;
    }
    .row-left{
        justify-content:flex-start;
    }
    .column{
        flex-direction: column;
    }
    .column-top{   
        align-items: flex-start;
    }
    .column-center{   
        align-items: center;
    }
    .column-bottom{   
        align-items: flex-end;
    }
</style>