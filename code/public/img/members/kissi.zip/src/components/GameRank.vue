<template>
    <div class="game-rank">
        <div class="left">
            <div class="thumb-wrap">
                <image class="thumb" :src="images.game_bg_3"></image>
                <image class="rank-num" :src="images.tag_rank3"></image>
            </div>
            <div class="info">
                <text class="name">庞建国</text>
                <text class="friends-num">3个好友在玩</text>
                <text class="comments-num">1000人评价</text>
            </div>
        </div>
        <div class="right">
            <text class="score">9.8</text>
        </div>
    </div>
</template>
<style scoped>
    .game-rank{
        flex-direction: row;
        justify-content:space-between;
        align-items: center;
        margin-bottom: 24px;
        padding-left: 40px;
    }
    .left{
        position: relative;
        justify-content: flex-start;
        align-items: center;
        flex-direction: row;
    }
    .thumb-wrap{
        position: relative;
        width: 128px;
        height: 160px;
        border-radius: 10px;
        overflow: hidden;
    }
    .thumb{
        width: 128px;
        height: 160px;
        border-radius: 10px;
        overflow: hidden;
    }
    .name{
        font-size: 32px;
        color: #000
    }
    .friends-num{
        font-size: 28px;
        color: #888888;
    }
    .comments-num{
        font-size: 28px;
        color: #888888;
    }
    .rank-num{
        width: 37px;
        height: 40px;
        position: absolute;
        right: 0;
        top:0;
        border-top-right-radius: 10px;
        overflow: hidden;
    }
    .info{
        padding-left: 30px;
        width: 450px;
    }
    .right{
        padding-right: 40px;
    }
    .score{
        font-family: BEBAS;
        font-size:36px;
        color: #ffc557
    }
</style>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
                images:images
            }
        }
    };
</script>
