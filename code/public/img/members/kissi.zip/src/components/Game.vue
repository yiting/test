<template>
    <div class="game">
        <image class="image" :src="images.game_bg_3"></image><image class="platform-tag" :src="images.tag_qq"></image><div class="info-1">
            <!-- images.tabweixin -->
            <text class="game-name">幻想砖块</text>
            <text class="score">8.9</text>
        </div><div class="info-2">
            <text class="game-tag">竞技</text>
            <text class="gap"> | </text>
            <text class="from">近日新货</text>
            <text class="gap" v-if="false"> | </text>
            <text class="comments-nums" v-if="false">2人点赞</text>
        </div>
    </div>
</template>
<style scoped>
    .game{
        position: relative;
        width: 270px;
        margin-right: 20px;
        border-radius: 10px;
        overflow: hidden;
    }
    .image{
        width: 270px;
        height: 338px;
        border-radius: 10px;
    }
    .info-1{
        margin-top: 20px;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
    }
    .game-name{
        font-size: 32px;
    }
    .score{
        font-family: BEBAS;
        color: #ffc557;
        font-size: 30px;
    }
    .info-2{
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        margin-top: 5px;
    }
    .platform-tag{
        position: absolute;
        left: 0;
        top: 0;
        width: 54px;
        height: 26px;
        border-top-left-radius: 10px;
    }
    .game-tag{
        color: #888888;
        font-size: 24px;
    }
    .gap{
        color: #888888;
        font-size: 24px;
    }
    .from{
        color: #888888;
        font-size: 24px;
    }
    .comments-nums{
        color: #888888;
        font-size: 24px;
    }
</style>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
                images:images,
            }
        }
    };
</script>