<template>
    <div class="user">
        <image class="user-avatar red-border" :src="images.avatar"></image>
        <div class="user-content">
            <div class="user-info">
                <text class="user-name">为游戏而生</text>
                <text class="role-tag role-type1">开发者</text>
            </div>
            <div class="user-sub-info">
                <text class="type1">推荐玩</text>
            </div>
        </div>
    </div>
</template>
<style scoped>
    .row{
        flex-direction: row;
    }
    .user{
        justify-content:flex-start;
        flex-direction: row;
        align-items: center;
        padding-top: 30px;
        padding-left: 30px;
    }
    .user-avatar{
        width: 80px;
        height: 80px;
        border-radius: 30px;
        margin-right: 20px;
    }
    .user-name{
        color: #000000;
        margin-right: 12px;
        font-size: 28px;
        padding-right: 10px;
    }
    .role-tag{
        height: 26px;
        line-height: 26px;
        padding-left: 12px;
        padding-right: 12px;
        border-radius: 6px;
        font-size: 16px;
    }
    .role-type1{
        background-color: #EFEEE8;
        color: #8B6E35;
    }
    .user-info,.user-sub-info{
        flex-direction: row;
        align-items: center;
        justify-content: flex-start;
    }
    .type1{
        font-size: 24px;
        color: #888888;
    }
</style>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
                images:images
            }
        },
        mounted() {
            // console.log(this._data.tabs)
            // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
        }
    };
</script>














