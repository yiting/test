<template>
    <div class="comment-wrap">
        <!-- 背景图 -->
        <image class="bg" :src="images.game_bg_1"></image>
        <!-- 玩家 -->
        <div class="player">
            <image class="player-avatar" :src="images.avatar"></image>
            <text class="player-name">卡恩金</text>
        </div>
        <!-- 评论 -->
        <text class="comment">玩法和画面精良，操作反馈优秀，一旦玩起来就停不下来了。玩法和画面精良，操作反馈优秀，一旦玩起来就停不下来了。
        </text>
        <!-- like -->
        <div class="like">
            <image class="like-image" :src="images.comment_list_like"></image>
            <text class="like-num">2323</text>
        </div>
        <!-- 游戏 -->
        <div class="game">
            <div class="game-left">
                <image class="game-thumb" :src="images.game_min"></image>
                <text class="game-name">跳一跳</text>
            </div>
            <div class="game-right">
                <text class="score">8.8</text>
            </div>

        </div>
    </div>
</template>
<style scoped>
    .comment-wrap{
        position: relative;
        height:388px;
        width: 325px;
        border-radius: 10px;
        overflow:hidden;
        margin-right: 20px;
    }
    /*玩家部分*/
    .player{
        padding-left: 20px;
        padding-top: 38px;
        flex-direction: row;
        justify-content: flex-start;
    }
    .player-avatar{
        width: 34px;
        height: 34px;
        border-width: 2px;
        border-style: solid;
        border-color: #fff;
        border-radius: 30px;
        margin-right: 5px
    }
    .player-name{
        color: #fff;
        font-size: 24px;
    }
    .comment{
        font-size: 28px;
        line-height: 42px;
        padding-bottom: 20px;
        padding-right:20px;
        padding-left:20px;
        padding-top:20px;
        color: #fff;
        lines:3;
        text-overflow: ellipsis;
    }
    /*like*/
    .like{
        justify-content: flex-start;
        align-items: center;
        flex-direction: row;
        padding-left: 20px;
    }
    .like-image{
        width: 22px;
        height: 22px;
        margin-right: 3px;
    }
    .like-num{
        color: #fff;
        font-size: 24px;
    }
    /*游戏部分*/
    .game{
        position: absolute;
        bottom: 0;
        left: 0;
        width: 325px;
        justify-content: space-between;
        align-items: center;
        flex-direction: row;
        height: 100px;
        padding-left: 20px;
        padding-right: 20px;
        background-color: rgba(0,0,0,.1);
    }
    .game-left{
        justify-content: flex-start;
        align-items: center;
        flex-direction: row;
    }
    .game-name{
        font-size: 24px;
        color: #ffffff;
    }
    .score{
        font-family: BEBAS;
        color: #fff;
        font-size: 24px;
    }
    .bg{
        position: absolute;
        left: 0;
        top: 0;
        height:388px;
        width: 325px;   
        border-radius: 10px;
    }
    .game-thumb{
        width: 48px;
        height: 60px;
        margin-right: 15px;
        border-radius: 6px;
    }
</style>
<script>
    import images from '../commom/images';
    export default {
        data() {
            return {
                images:images
            }
        }
    };
</script>
