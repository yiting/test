<template>
    <!-- 写评论 -->
    <div class="edit-mod edit-comments-mod"  v-if='true'>
        <scroller class="scroller">
            <div class="edit-head">
                <div class="edit-head-left">
                    <image class="edit-close" :src="images.dialog_close_1"></image>
                </div>
                <div class="edit-head-center">
                    <text class="game-name">跳一跳</text>
                </div>
                <div class="edit-head-right"></div>
            </div>
            <!-- 打分 -->
            <Scoring></Scoring>
            <!-- 打分结果 -->
            <div class="SelectedComment-wrap">
                <SelectedComment></SelectedComment>
            </div>
            <!-- 编辑 -->
            <div class="edit-content">
                <textarea class="textarea" placeholder="分享你对游戏的看法…" autoAppear="false">
                </textarea>
            </div>
            <!-- 发表 -->
            <!-- 发表后分享 -->
            <div class="publish">
                <div class="column column-center info-x1-wrap">
                    <div class="row column-center row-center switch">
                        <!-- radiobox_checked 选择 -->
                        <image class="radiobox" :src="images.radiobox_checked"></image>
                        <text class="info-x1">发表后分享</text>
                    </div>
                </div>
                <!-- publish-btn-disable+publish-btn-text-disable 变灰色-->
                <div class="publish-btn publish-btn-disable">
                    <text class="publish-btn-text publish-btn-text-disable">发表</text>
                </div>
            </div>
        </scroller>
    </div>
</template>
<script>
    import images from '../commom/images';
    import Scoring from './Scoring.vue'
    import SelectedComment from './SelectedComment.vue'
    export default {
        data() {
            
            return {
               "images":images 
            }
        },
        components: {
            Scoring,SelectedComment
        },
        mounted() {
            // console.log(this._data.tabs)
            // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
        }
    };
</script>
<style scoped>
    .row{
        flex-direction: row;
    }
    .row-right{
        justify-content:flex-end;
    }
    .row-center{
        justify-content:center;
    }
    .row-between{
        justify-content:space-between;
    }
    .row-around{
        justify-content:space-around;
    }
    .row-left{
        justify-content:flex-start;
    }
    .column{
        flex-direction: column;
    }
    .column-top{   
        align-items: flex-start;
    }
    .column-center{   
        align-items: center;
    }
    .column-bottom{   
        align-items: flex-end;
    }
    .SelectedComment-wrap{
        padding-left: 40px;
        padding-right: 40px;
    }
    .game-name{
        font-size: 36px;
    }
    /*写*/
    .edit-mod{
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        width: 750px;
        background-color: #ffffff;
    }
    .edit-head{
        justify-content: space-between;
        align-items: center;
        height: 128px;
        flex-direction: row;
        padding-top: 38px;
    }
    .edit-head-right {
        padding-right: 40px;
        width: 200px;
    }
    .edit-head-left {
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        padding-left: 40px;
        width: 200px;
    }
    .edit-close{
        width: 31px;
        height: 31px;
    }
    /*edit-comment-content*/
    .edit-content{
        border-top-width: 1px;
        border-style: solid;
        border-color: #e1e1e1;
        margin-left: 40px;
        width: 670px;
        margin-top: 30px;
    }
    .publish{
        position: fixed;
        bottom: 0;
        left: 0;
        width: 750px;
    }
    .textarea {
        font-size: 32px;
        padding-top: 20px;
        padding-bottom: 20px;
        color: #666666;
        height: 300px;
    }
    .radiobox{
        width: 40px;
        height: 40px;
    }
    .info-x1-wrap{
        padding-bottom: 24px;
    }
    .info-x1{
        color: #888888;
        font-size: 28px;
        margin-left: 12px;
    }
    .publish-btn{
        height: 110px;
        width: 750px;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        background-color: #00D6D7;
    }
    .publish-btn-text{
        color: #ffffff;
        font-size: 36px;
    }
    .publish-btn-text-disable{
        color: #888888;
    }
    .publish-btn-disable{
        background-color: #E3E3E3
    }

    .choise-platform-mod{
        position: fixed;
        top: 0;
        left: 0;
        width: 750px;
        bottom: 0;
        background-color: rgba(0,0,0,.5);
        flex-direction: column;
        justify-content: flex-end;
        align-items: center;
    }
    .choise-platform{
        width: 750px;
        height: 333px;
        background-color: #ffffff;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    .choise-platform-head{
        justify-content: center;
        flex-direction: row;
        align-items: center;
    }
    .choise-platform-head-text{
        font-size: 24px;
        color: #bbbbbb;
        padding-left: 10px;
        padding-right: 10px;
    }
    .choise-platform-head-line{
        height: 2px;
        width: 30px;
        background-color: #d8d8d8;
    }
    .choise-platform-body{
        width: 500px;
        padding-top: 40px;
        justify-content: space-around;
        flex-direction: row;
        align-items: center;
    }
    .choise-platform-ico{
        width: 120px;
        height: 120px;
    }

</style>