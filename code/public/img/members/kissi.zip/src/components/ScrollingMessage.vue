<template>
    <div class="scrolling-message">
        <div class="message-item-group" ref="listScrollWrap">
            <div class="message-item" v-for="(message,index) in messageList">
                <image class="avatar" :src="images.avatar"></image>
                <text class="name">卡恩</text>
                <text class="content">{{message.name}}刚刚赞了幻想砖块</text>
                <image class="right-arrow" :src="images.right_arrow"></image>
            </div>
        </div>
    </div>
</template>
<style scoped>
    .scrolling-message{
        width: 750px;
        height: 112px;
        overflow: hidden;
    }
    .message-item-group{
        width: 750px;
        flex-direction: column;
        align-items:center;
        justify-content: flex-start;
    }
    .message-item{
        width: 670px;
        justify-content: flex-start;
        align-items: center;
        flex-direction: row;
        height: 112px;
    }
    .message-item:active{
        opacity: .7
    }
    .avatar{
        width: 32px;
        height: 32px;
        border-radius: 16px;
        margin-right: 12px;
    }
    .name{
        margin-right: 12px;
        font-size: 28px;
    }
    .content{
        font-size: 28px;
    }
    .right-arrow{
        position: absolute;
        width: 10px;
        height: 17px;
        top: 47px;
        right: 0px;
    }
</style>
<script>
    import images from '../commom/images';
    const animation = weex.requireModule('animation');
    const modal = weex.requireModule('modal')
    export default {
        data() {
            return {
                images:images,
                timmer:null,//定时器
                messageList:[
                    {
                        name:1,
                    },
                    {

                        name:2,
                    }
                ]
            }
        },
        created:function(){
            //轮播
            var that=this;
            that.messageList=that.messageList.concat(that.messageList[0])
            setTimeout(function(){
                that.showList(that.messageList); 
            },2000)
            //轮播
        },
        methods:{
            showList(listGroup){
                if(listGroup.length==2){
                    return
                }
                var that=this;
                var oneStepLength=112;
                var total=listGroup.length;
                var index=0;
                var duration=2000;
                that.timmer && clearInterval(that.timmer);
                function move(index,duration,callback){
                    animation.transition(that.$refs.listScrollWrap, {
                        styles: {
                            transform: `translateY(${-oneStepLength * index}px)`,
                        },
                        duration: duration, 
                        timingFunction: 'ease',
                        delay: 0 
                    }, () => {
                        callback && callback()
                    });
                };
                that.timmer=setInterval(function(){
                    move(index++,400,function(){
                        if(index==(total)){
                            index=0;
                            move(0,0)
                        }
                    });
                },duration)
            } 
        }

    }
</script>