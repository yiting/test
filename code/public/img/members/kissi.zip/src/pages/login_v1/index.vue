<template>
    <div class="page">
        <!-- 导航 -->
        <nav nav-title="我的"></nav>
        <!-- 容器 -->
        <div class="wrapper">
            <image class="login-logo" :src="images.logo"></image>
            <image class="app-name" :src="images.app_name"></image>
            <text class="slogen">桌住好玩的小游戏</text>
            <div class="enter-group">
                <div class="enter">
                    <image class="enter-img" :src="images.qq_logo_circle_1"></image>
                    <span class="login-type-name">QQ登陆</span>
                </div>
                <div class="enter">
                    <image class="enter-img" :src="images.wechat_logo_circle_1">
                    </image>
                    <span class="login-type-name">微信登陆</span>
                </div>
            </div>

        </div>
        <!-- dialog -->
        <div class="dialog" v-if="true">
            <div class="dialog-mask">
            </div>
            <div class="dialog-content">
                <div class="dialog-content-inner">
                    <div class="dialog-header">
                        <text class="header-title">验证邀请码</text>
                    </div>
                    <div class="dialog-body">
                        <text class="test-tips">App内测中，仅向有邀请码的小可爱开放哦～如果没有邀请码，请等待一点时间，小桌变得更好以后向所有人开放～</text>
                        <input type="text" placeholder="输入邀请码" class="input" :autofocus=true />
                        <div class="btn-wrap">
                            <div class="submit-btn">提交</div>
                        </div>
                    </div>
                </div>
                <image class="dialog-close" :src="images.dialog_close"></image>
            </div>
        </div>
    </div>
</template>
<script>
import Nav from '../../components/Nav.vue'
import images from '../../commom/images'
export default {
    data() {
        return {
            "images": images
        }
    },
    components: {
        Nav
    },
    mounted() {
        // console.log(this._data.tabs)
        // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
    }
}
</script>
<style src="./index.css">