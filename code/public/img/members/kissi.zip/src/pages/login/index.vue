<template>
    <div class="page">
        <!-- 导航 -->
        <nav nav-title="我的"></nav>
        <!-- 容器 -->
        <div class="wrapper">
            <image class="login-logo" :src="images.login"></image>
            <div class="login-tips">登录圆桌，畅玩小游戏</div>
            <text class="login-btn">立即登陆</text>
        </div>
        <!-- dialog -->
        <div class="dialog" v-if="true">
            <div class="dialog-mask">
            </div>
            <div class="dialog-content">
                <div class="dialog-content-inner">
                    <div class="dialog-header">
                        <text class="header-title">请选择登录账号</text>
                    </div>
                    <div class="dialog-body">
                        <div class="enter-group">
                            <div class="enter">
                                <image class="enter-img" :src="images.qq_logo_circle"></image>
                                <span class="login-type-name">QQ</span>
                            </div>
                            <div class="enter">
                                <image class="enter-img" :src="images.wechat_logo_circle">
                                </image>
                                <span class="login-type-name">微信</span>
                            </div>
                        </div>
                    </div>
                </div>
                <image class="dialog-close" :src="images.dialog_close"></image>
            </div>
        </div>
    </div>
</template>
<script>
import Nav from '../../components/Nav.vue'
import images from '../../commom/images'
export default {
    data() {
        return {
            "images": images
        }
    },
    components: {
        Nav
    },
    mounted() {
        // console.log(this._data.tabs)
        // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
    }
}
</script>
<style src="./index.css">