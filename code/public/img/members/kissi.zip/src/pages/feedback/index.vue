<template>
    <div class="page">
        <!-- 导航 -->
        <Nav back="true" nav-title="意见反馈"></Nav>
        <scroller class="scroller">
            <!-- 编辑 -->
            <div class="edit-content">
                <textarea class="textarea" placeholder="分享你对游戏的看法…" autofocus="true">
                    
                </textarea>
                <div class="texts-num">
                    <text class="texts-num-text">0/400</text>
                </div>
            </div>
            <div class="edit-phone">
                <textarea class="textarea-phone" placeholder="留个手机号码可好（不想就算了）">
                    
                </textarea>
            </div>
            <!-- 提交反馈-->
            <div class="submit">
                <!-- submit-btn-disable+submit-btn-text-disable 变灰色-->
                <div class="submit-btn">
                    <text class="submit-btn-text">提交</text>
                </div>
            </div>
        </scroller>
    </div>
</template>
<script>
import Nav from '../../components/Nav.vue'
import images from '../../commom/images'
export default {
    data() {
        return {
            "images": images
        }
    },
    components: {
        Nav
    },
    mounted() {
        // console.log(this._data.tabs)
        // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
    }
};
</script>
<style src="./index.css">