<template>
    <div class="page" >
        <!-- 导航 -->
        <nav 
        nav-title="圆桌" 
        border="border" 
        :avatar="images.avatar" 
        search="search" 
        :navStyle="navStyle" 
        :navTitleStyle="navTitleStyle"
        ></nav>
        <scroller class="scroller">
            <!-- 最佳新游 -->
            <div class="mod best-game pr0 mt0">
                <div class="mod-head pr40">
                    <div class="mod-head-left">
                        <text class="mod-title">最佳新游</text>
                    </div>
                    <div class="mod-head-right">
                        <image :src="images.more" class="more"></image>
                    </div>
                </div>
                <Banner></Banner>
            </div>
            <!-- 玩家热评 -->
            <div class="mod best-game pr0">
                <div class="mod-gap"></div>
                <div class="mod-head pr40">
                    <div class="mod-head-left">
                        <text class="mod-title">玩家热评</text>
                    </div>
                    <!-- <div class="mod-head-right">
                        <image :src="images.more" class="more"></image>
                    </div> -->
                </div>
                <scroller class="scroller-row" scrollDirection="horizontal" show-scrollbar="false">
                    <HotComment></HotComment>
                    <HotComment></HotComment>
                    <HotComment></HotComment>
                    <HotComment></HotComment>
                    <HotComment></HotComment>
                    <HotComment></HotComment>
                </scroller>
                <ScrollingMessage></ScrollingMessage>
            </div>
            <!-- 淘新游 -->
            <div class="mod best-game pr0 pb20">
                <div class="mod-gap"></div>
                <div class="mod-head pr40">
                    <div class="mod-head-left">
                        <text class="mod-title">淘新游</text>
                    </div>
                </div>
                <scroller class="scroller-row scroller-game" scrollDirection="horizontal" show-scrollbar="false">
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                </scroller>
            </div>
            <!-- QQ排行 -->
            <div class="mod best-game pr0 pb10">
                <div class="mod-gap"></div>
                <div class="mod-head pr40">
                    <div class="mod-head-left">
                        <div class="item">
                            <text class="mod-title">QQ排行</text>
                           <!--  <div class="mod-title-line"></div> -->
                        </div>
                        <div class="mod-title-gap"></div>
                        <div class="item">
                            <text class="mod-title mod-title-gray">微信排行</text>
                            <!-- <div class="mod-title-line"></div> -->
                        </div>
                    </div>
                    <div class="mod-head-right">
                        <image :src="images.more" class="more"></image>
                    </div>
                </div>
                <div class="gameRank-wrap">
                    <GameRank></GameRank>
                    <GameRank></GameRank>
                    <GameRank></GameRank>
                </div>
            </div>
            <!-- 竞技 -->
            <div class="mod best-game pr0 pb20">
                <div class="mod-gap"></div>
                <div class="mod-head pr40">
                    <div class="mod-head-left">
                        <text class="mod-title">竞技</text>
                    </div>
                    <div class="mod-head-right">
                        <image :src="images.more" class="more"></image>
                    </div>
                </div>
                <scroller class="scroller-row scroller-game" scrollDirection="horizontal" show-scrollbar="false">
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                </scroller>
            </div>
            <!-- 解迷 -->
            <div class="mod best-game pr0 pb20">
                <div class="mod-gap"></div>
                <div class="mod-head pr40">
                    <div class="mod-head-left">
                        <text class="mod-title">解迷</text>
                    </div>
                    <div class="mod-head-right">
                        <image :src="images.more" class="more"></image>
                    </div>
                </div>
                <scroller class="scroller-row scroller-game" scrollDirection="horizontal" show-scrollbar="false">
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                </scroller>
            </div>
            <!-- 今日骑士 -->
            <div class="mod best-game pr0">
                <div class="mod-gap"></div>
                <div class="mod-head pr40">
                    <div class="mod-head-left">
                        <text class="mod-title">今日骑士</text>
                    </div>
                    <div class="mod-head-right">
                        <image :src="images.more" class="more"></image>
                    </div>
                </div>
                <div class="king">
                    <King></King>
                    <King></King>
                </div>
            </div><!-- 竞技 -->
            <div class="mod best-game pr0 pb20">
                <div class="mod-gap"></div>
                <div class="mod-head pr40">
                    <div class="mod-head-left">
                        <text class="mod-title">竞技</text>
                    </div>
                    <div class="mod-head-right">
                        <image :src="images.more" class="more"></image>
                    </div>
                </div>
                <scroller class="scroller-row scroller-game" scrollDirection="horizontal" show-scrollbar="false">
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                </scroller>
            </div>
            <!-- 解迷 -->
            <div class="mod best-game pr0 pb20">
                <div class="mod-gap"></div>
                <div class="mod-head pr40">
                    <div class="mod-head-left">
                        <text class="mod-title">解迷</text>
                    </div>
                    <div class="mod-head-right">
                        <image :src="images.more" class="more"></image>
                    </div>
                </div>
                <scroller class="scroller-row scroller-game" scrollDirection="horizontal" show-scrollbar="false">
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                    <Game></Game>
                </scroller>
            </div>
            <!-- 页脚空白 -->
            <div class="footer-blank"></div>
        </scroller>
    </div>
</template>
<script>
import images from '../../commom/images';
import fonts from '../../commom/fonts';
import Nav from '../../components/Nav.vue'
import Banner from '../../components/Banner.vue'
import HotComment from '../../components/HotComment.vue'
import King from '../../components/King.vue'
import Game from '../../components/Game.vue'
import GameRank from '../../components/GameRank.vue'
import ScrollingMessage from '../../components/ScrollingMessage.vue'
const modal = weex.requireModule('modal')
let domModule = weex.requireModule('dom');
export default {
    data() {
        return {
            images:images,
            navStyle:{
                "backgroundColor":"#00D6D7",
                "borderBottomColor":"#00D6D7"
            },
            navTitleStyle:{
                "color":"#ffffff"
            }
        }
    },
    created() {
        domModule.addRule('fontFace', {
            'fontFamily': "BEBAS",
            'src': "url('"+fonts.BEBAS+"')"
        });
    },
    components: { 
        Nav, Banner ,HotComment,Game,King,GameRank,ScrollingMessage
    }
};
</script>
<style src="./index.css" scoped>