<template>
    <div class="page">
        <scroller class="scroller">
            <Nav></Nav>
            <div class="mod wait-comment-games">
                <div class="mod-header">
                    <text class="main-title">我有我态度</text>
                    <text class="mod-desc">你的评价可以帮助游戏变得更好</text>
                </div>
            </div>
            <div class="GameListComment-mod">
                <GameListComment></GameListComment>
                <GameListComment></GameListComment>
                <GameListComment></GameListComment>
            </div>
            <div class="mod">
                <div class="mod-gap"></div>
                <div class="mod-header">
                    <text class="mod-title">新游测评邀请</text>
                    <div class="progress">
                        <text class="progress-value">1/3</text>
                    </div>
                </div>
                <scroller class="scroller-row" scrollDirection="horizontal" show-scrollbar="false">
                    <GameListInviteComment></GameListInviteComment>
                    <GameListInviteComment></GameListInviteComment>
                    <GameListInviteComment></GameListInviteComment>
                </scroller>
            </div>
            <div class="GameListComment-mod">
                <div class="mod-gap"></div>
                <GameListComment></GameListComment>
                <GameListComment></GameListComment>
                <GameListComment></GameListComment>
            </div>
            <!-- 页脚空白 -->
            <div class="footer-blank"></div>
        </scroller>
        <!-- 编辑评论 -->
        <EditShare v-if="false"></EditShare>
    </div>
</template>
<script>
import Nav from '../../components/Nav.vue'
import images from '../../commom/images'
import GameListComment from '../../components/GameListComment.vue'
import GameListInviteComment from '../../components/GameListInviteComment.vue'
import EditComment from '../../components/EditComment.vue'
import EditShare from '../../components/EditShare.vue'
export default {
    data() {
        return {
            images:images
        }
    },
    components: {
        Nav,GameListComment,GameListInviteComment,EditShare,EditComment
    },
    mounted() {
        // console.log(this._data.tabs)
        // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
    }
};
</script>
<style src="./index.css" scoped>