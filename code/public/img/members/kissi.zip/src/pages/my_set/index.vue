<template>
    <div class="page">
        <!-- 导航 -->
        <nav nav-title="我的设置"></nav>
        <scroller class="scroller">
            <!--个人信息区域-->
            <div class="list">
                <div class="item">
                    <div class="left">
                        <text class="item-name">头像</text>
                    </div>
                    <div class="right">
                        <image class="avatar" :src="images.avatar"></image>
                    </div>
                </div>
                <div class="item no-border">
                    <div class="left">
                        <text class="item-name">昵称</text>
                    </div>
                    <div class="right">
                        <text class="item-content">泰勒斯威夫特</text>
                    </div>
                </div>
            </div>
            <!--退出按钮-->
            <div class="sign-out-btn">
                <text class="sign-out-label">退出登录</text>
            </div>
        </scroller>
    </div>
</template>
<script>
import Nav from '../../components/Nav.vue'
import images from '../../commom/images'
export default {
    data() {
        return {
            images:images
        }
    },
    components: {
        Nav
    },
    mounted() {
        // console.log(this._data.tabs)
        // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
    }
}
</script>
<style src="./index.css">