<template>
    <div class="page">
        <!-- 导航 -->
        <nav nav-title="高分佳作" back="back"></nav>
        <tab :tabs="tabs" @showTab="showTab" :tabIndex='tabIndex'></tab>
        <div class="tab-content" ref="tabcontent" :style="'width:'+tabContentWidth+'px'">
            <div class="tab-item">
                <scroller class="scroller ">
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <GameList showRank="1"></GameList>
                    <!-- qq -->
                    <!-- 微信 -->
                    <!-- 页脚空白 -->
                    <div class="footer-blank"></div>
                </scroller>
            </div>
            <div class="tab-item">
                <scroller class="scroller ">
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <GameList showRank="2"></GameList>
                    <!-- qq -->
                    <!-- 微信 -->
                    <!-- 页脚空白 -->
                    <div class="footer-blank"></div>
                </scroller>
            </div>
        </div>
    </div>
</template>
<style src="./index.css"></style>
<script>
import Nav from '../../components/Nav.vue'
import Tab from '../../components/Tab.vue'
import GameList from '../../components/GameList.vue'
const animation = weex.requireModule('animation');
const modal = weex.requireModule('modal')
export default {
    data() {
        return {
            tabs: [
                { name: "QQ榜", current: true },
                { name: "微信榜", current: false }
            ],
            tabIndex:0,
            tabContentWidth:1
        }
    },
    components: {
        Nav,
        Tab,
        GameList
    },
    created(){
        this.tabContentWidth=this.tabs.length*750;
    },
    methods: {
        showTab(index) {
            this.tabIndex=index;
            const distance = 750 * index;
            animation.transition(this.$refs.tabcontent, {
                styles: {
                    transform: `translateX(${-distance}px)`,
                },
                duration: 400, //ms
                timingFunction: 'ease',
                delay: 0 //ms
            }, () => {});
        }
    }
}
</script>