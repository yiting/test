<template>
    <div class="page">
        <!-- 导航 -->
        <nav navTitle="竞技" back="back" search="search"></nav>
        <div class="wrapper">
            <div class="side-left">
                <scroller class="scroller type-scroller" showScrollbar="false">
                    <div class="game-type-list">
                        <div class="type-item type-item-current">
                            <text class="type-text">全部</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">操作</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                        <div class="type-item">
                            <text class="type-text">竞技</text>
                        </div>
                    </div>
                </scroller>
            </div>
            <div class="side-right">
                <!-- 过滤 -->
                <div class="filter">
                    <div class="filter-item">
                        <div class="filter-type">
                            <text class="filter-type-name">排序</text>
                        </div>
                        <div class="filter-name-group">
                            <text class="filter-name filter-name-current">高分</text>
                            <text class="filter-name">最新</text>
                        </div>
                    </div>
                    <div class="filter-item">
                        <div class="filter-type">
                            <text class="filter-type-name">平台</text>
                        </div>
                        <div class="filter-name-group">
                            <text  class="filter-name filter-name-current">不限</text>
                            <text  class="filter-name">QQ</text>
                            <text  class="filter-name">微信</text>
                        </div>
                    </div>
                </div> 
                <scroller class="scroller filter-game-list">
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <GameList></GameList>
                    <!-- 页脚空白 -->
                    <div class="footer-blank"></div>
                </scroller>
            </div>
        </div>  
    </div>
</template>
<script>
import Nav from '../../components/Nav.vue'
import GameList from '../../components/GameList.vue'
export default {
    data() {
        return {}
    },
    components: { 
        Nav, GameList 
    }
}
</script>
<style src="./index.css">