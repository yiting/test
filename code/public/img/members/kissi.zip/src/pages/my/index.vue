<template>
    <div class="page">
        <Nav navTitle="我"></Nav>
        <!-- 导航 -->
        <scroller class="scroller">
            <div class="my">
                <div class="my-info">
                    <image class="avatar" :src="images.avatar"></image>
                    <text class="namea">泰勒·斯威夫特</text>
                    <text class="game-title">见习骑士</text>
                </div>
                <div class="social-info">
                    <div class="social-info-item">
                        <text class="social-num">135</text>
                        <text class="social-text">发表态度</text>
                    </div>
                    <div class="social-info-item">
                        <text class="social-num">48</text>
                        <text class="social-text">发表评论</text>
                    </div>
                    <div class="social-info-item">
                        <text class="social-num">55</text>
                        <text class="social-text">被赞</text>
                    </div>
                </div>
            </div>
            <div class="mod-gap"></div>
            <div class="list-header">
                <div class="left">
                    <text class="list-title">玩过的游戏</text>
                </div>
                <div class="right">
                    <div class="see-recommend" v-if="false">
                        <!--未选择-->
                        <image class="radio" :src="images.radiobox"></image>
                        <text class="sr-text">只看我推荐</text>
                    </div>
                </div>
            </div>
            <!-- 不限 -->
            <div class="list">
                <GameListHistory></GameListHistory>
                <GameListHistory></GameListHistory>
                <GameListHistory></GameListHistory>
                <GameListHistory></GameListHistory>
                <GameListHistory></GameListHistory>
                <GameListHistory></GameListHistory>
            </div>
            <!-- qq -->
            <!-- 微信 -->
            <!-- 页脚空白 -->
            <div class="footer-blank"></div>
        </scroller>
    </div>
</template>
<script>

    import Nav from '../../components/Nav.vue'
    import GameListHistory from '../../components/GameListHistory.vue'
    import images from '../../commom/images'
    export default {
        data() {
            return {
                "images": images
            }
        },
        components: {
            Nav, GameListHistory
        },
        mounted(){
            // console.log(this._data.tabs)
            // this._data.tabs=[{name:"不限",current:true},{name:"QQ"},{name:"微信",current:true}];
        }
    };
</script>
<style src="./index.css">