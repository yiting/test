<template>
  <wxc-tab-bar :tab-titles="tabTitles"
               :tab-styles="tabStyles"
               title-type="icon"
               @wxcTabBarCurrentTabSelected="wxcTabBarCurrentTabSelected">
    <!--The first page content-->
    <div class="item-container" :style="contentStyle">
      <!-- <text>23sadfasdfsfd</text> -->
      <index></index>
    </div>
    <!--The second page content-->
    <div class="item-container" :style="contentStyle">
      <MyAtitude></MyAtitude>
    </div>
    <!-- The third page content-->
    <div class="item-container" :style="contentStyle">
      <my></my>
    </div>
  </wxc-tab-bar>
</template>

<style scoped>
  .item-container {
    width: 750px;
    background-color: #ffffff;
    align-items: flex-start;
    justify-content: flex-start;
    position: relative;
  }
</style>
<script>
  import { WxcTabBar, Utils } from 'weex-ui';
  import index from '../index/index.vue'
  import MyAtitude from '../my_attitude/index.vue'
  import login from '../login/index.vue'
  import my from '../my/index.vue'
  const modal = weex.requireModule('modal')
  // https://github.com/alibaba/weex-ui/blob/master/example/tab-bar/config.js 
  import Config from './config'
  export default {
    components: { WxcTabBar,index,login,MyAtitude,my},
    data: () => ({
      tabTitles: Config.tabTitles,
      tabStyles: Config.tabStyles
    }),
    created () {
      // const tabPageHeight = Utils.env.getPageHeight();
      // const deviceHeight=this.$getConfig().env.deviceHeight;
      const { tabStyles } = this;
      // If the page doesn't have a navigation bar
      const tabPageHeight = this.$getConfig().env.deviceHeight / this.$getConfig().env.deviceWidth * 750;
      // console.dir(this.$getConfig().env)
      // modal.toast({'message':this.$getConfig().env.deviceHeight, 'duration': 5});
      // modal.toast({'message':this.$getConfig().env.deviceHeight, 'duration': 10});
      


      // 导航的高度
      this.contentStyle = { height: (tabPageHeight - tabStyles.height) + 'px' };
    },
    methods: {
      wxcTabBarCurrentTabSelected (e) {
        const index = e.page;
        // console.log(index);
      }
    }
  };
</script>