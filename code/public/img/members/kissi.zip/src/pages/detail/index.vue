<template>
    <div class="page">
        <!-- 导航 -->
        <scroller class="scroller" @scroll="scrollPage">
            <!--游戏详情区域 -->
            <div class="detail">
                <!-- 游戏封面信息区域-->
                <div class="banner-panel">
                    <!--素材图 -->
                    <image class="banner-img" :src="images.banner_1"></image>
                    <!--遮罩mask-->
                    <image class="banner-mask" src="images.banner_mask"></image>
                    <div class="banner-info">
                        <!-- 游戏简介-->
                        <div class="banner-row game-name-row">
                            <text class="row-label game-name">跳一跳</text>
                            <text class="row-val game-score">8.9</text>
                        </div>
                        <!--游戏平台-->
                        <div class="banner-row game-platform-row">
                            <text class="row-label game-platform">游戏平台:</text>
                            <image class="platform-ico platform-qq-ico"
                                   :src="images.qq_logo_circle"></image>
                            <image class="platform-ico platform-weixin-ico"
                                   :src="images.wechat_logo_circle"></image>
                        </div>
                        <!-- 游戏类型-->
                        <div class="banner-row game-author-row">
                            <text class="row-label game-author">游戏开发:</text>
                            <text class="row-val">独立精神</text>
                        </div>
                        <!-- 游戏类型-->
                        <div class="banner-row game-type-row">
                            <text class="row-label game-type">游戏类型:</text>                            <text class="game-type-val">休闲</text>
                            <text class="game-type-val">竞技</text>
                            <text class="game-type-val">MOBA</text>
                        </div>
                    </div>
                </div>
                <!--开发者的话区域-->
                <div class="game-author-panel">
                    <div class="author-content-panel">
                        <text class="author-say">开发者的话</text>
                        <div class="author-say-content">
                            <text class="say-content-text">这是一款低龄向的益智类游戏，游戏有着精美可爱的画风和好听的背景旋律。高度自由的开放关卡设计玩家可以借助关卡中的任何道,高度混水</text>
                            <a class="search-more-href">
                                <text class="search-more">查看全部</text>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <text class = "hint">{{hint}}</text>
            <!-- 打分 -->
            <Scoring></Scoring>
            <div class="scoring-mod">
                <!-- 精选评论 -->
                <SelectedComment></SelectedComment>
            </div>
            <div class="mod-gap"></div>    
            <!-- 得分 -->
            <div class="score-mod">
                <Score></Score>
            </div>
            <!-- 评论列表 -->
            <div class="comments-mod">
                <div class="row row-between comments-head">
                    <div class="row row-left column-center">
                        <text class="comments-title">评价</text>
                        <text class="comments-num">68</text>
                    </div>
                    <div class="row row-left column-center">
                        <div class="row row-left column-center sort-item">
                            <image class="comment-list-sort" :src="images.comment_list_sort"></image>
                            <text class="sort-item-text">按赞数</text>
                        </div>
                    </div>
                </div>
                <div class="comments-list">
                    <Comment></Comment>
                    <Comment></Comment>
                    <Comment></Comment>
                    <Comment></Comment>
                    <Comment></Comment>
                </div>
            </div>
            <!-- 写评论&玩一玩 入口-->
            <div class="comment-Play row row-around column-center">
                <!-- btn-disable +btn-disable-text -->
                <div class="comment-play-btn btn-disable">
                    <text class="comment-play-btn-text btn-disable-text">写评论</text>
                </div>
                <div class="comment-play-btn comment-play-btn-current">
                    <text class="comment-play-btn-text comment-play-btn-text-current">玩一玩</text>
                </div>
            </div>
            <!-- 选择平台 -->
            <div class="choise-platform-mod" v-if='false'>
                <div class="choise-platform">
                    <div class="choise-platform-head">
                        <div class="choise-platform-head-line"></div>
                        <text class="choise-platform-head-text">这款游戏怎么样?</text>
                        <div class="choise-platform-head-line"></div>
                    </div>  
                    <div class="choise-platform-body">
                        <image class="choise-platform-ico" :src="images.qq_logo_circle"></image>
                        <image class="choise-platform-ico" :src="images.wechat_logo_circle"></image>
 
                    </div>
                </div>
            </div>
            <!-- 写评论 -->
            <EditComment v-if="false"></EditComment>
            <!-- 写分享 -->
            <EditShare v-if="false"></EditShare>
            <Share v-if="false"></Share>
            <!-- 页脚空白 -->
            <div class="footer-blank"></div>
        </scroller>
        <!--顶部导航 -->
        <Nav navTitle="" :back="back" :back_white="back_white"  :share="share" :share_white="share_white" transparentBg="true" class="nav-top" :style="navStyle"></Nav> 
    </div>
</template>
<script>
    import images from '../../commom/images';
    import Nav from '../../components/Nav.vue'
    import SelectedComment from '../../components/SelectedComment.vue'
    import Comment from '../../components/Comment.vue'
    import Score from '../../components/Score.vue'
    import Scoring from '../../components/Scoring.vue'
    import Share from '../../components/Share.vue'
    import EditComment from '../../components/EditComment.vue'
    import EditShare from '../../components/EditShare.vue'
    const modal = weex.requireModule('modal')
    export default {
        data() {
            return{
                images:images,
                hint:"",
                back:false,
                back_white:false,
                share:false,
                share_white:false,
                navStyle:{
                    backgroundColor:"rgba(255,0,0,0.0)"
                }
            }
        },
        components: {
            Nav,SelectedComment,Comment,Score,Scoring,Share,EditShare,EditComment
        },
        methods: {
            scrollPage:function(e){
                this.offsetY = e.contentOffset.y;
                this.hint = "offsetY:" +this.offsetY;
                // this.navStyle.backgroundColor="rgba(255,0,0,"+Math.min(1.0,this.offsetY/200)+")"
                this.navStyle.backgroundColor="rgba(255,255,255,"+this.offsetY/100*-1+")"
                if(this.offsetY<-100){
                    this.back=true;
                    this.backW=false;
                }
            }
        }
    };
</script>
<style src="./index.css"/>



























































